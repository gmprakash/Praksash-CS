
1] Import the project in eclipse.
To test the code either
1.1] Run BasketPriceCalculatorTest.java 
   add different scenarios to verify the logic.
OR

1.2] run a main class:
  Basket.java
2]Enter one fruit at a time and hint enter.

Once you entered enough fruits just hit enter to calculate the price and terminate the program.


Note: Please ignore SOPs in the main class as adding logs and making it perfect would take 
more than 2 hours.