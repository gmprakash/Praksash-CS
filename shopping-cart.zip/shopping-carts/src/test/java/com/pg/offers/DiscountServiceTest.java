package com.pg.offers;


import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.pg.offers.impl.DiscountServiceImpl;
import com.pg.price.ProductType;

public class DiscountServiceTest {

	DiscountService  discountService;
	
	@BeforeTest
	public void setUp(){
		discountService = new DiscountServiceImpl();
	}
	
	@DataProvider(name="fruitDiscountDataProvider")
	public Object[][] getFruitDiscountDataProvider() {
		return new Object[][] {
				//Add more scenarios here
				{ProductType.APPLE, 5,5},	//No discount
				{ProductType.BANANA,2,2},
				{ProductType.LIME, 3,2},	// 3 for the price of 2
				{ProductType.LIME, 6,4},	
				{ProductType.LIME, 2,2},	// for 2 no discount
				{ProductType.LIME, 5,4},	// first 3 charged for 2 plus remaining 2.
				{ProductType.MELON, 1,1},	// no discount on sigle
				{ProductType.MELON, 2,1},	//buy one get one
				{ProductType.MELON, 3,2},
				{ProductType.MELON, 4,2},
			};
	}
	
	@Test(dataProvider="fruitDiscountDataProvider")
	public void testApplyDiscount(ProductType productType,int quantity,int discountedQuantity){
		Assert.assertEquals(discountService.applyDiscount(productType, quantity),discountedQuantity);
	}
}
