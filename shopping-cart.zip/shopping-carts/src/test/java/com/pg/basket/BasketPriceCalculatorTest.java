package com.pg.basket;

import java.util.Arrays;
import java.util.List;

import org.testng.Assert;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.pg.basket.impl.BasketPriceCalculatorImpl;


public class BasketPriceCalculatorTest {
	
	BasketPriceCalculator basketPriceCalculator;
	@BeforeTest
	public void setUp(){
		basketPriceCalculator = new BasketPriceCalculatorImpl();
	}
	
	@DataProvider(name="basketDataProvider")
	public Object[][] getBasketDataProvider() {
		return new Object[][] {
				//Add more scenarios here
				{Arrays.asList("Apple", "Banana", "Lime", "Melon", "Melon"),1.2},
				{Arrays.asList("Melon", "Melon", "Melon", "Melon", "Melon"),1.5},
				{Arrays.asList("Apple","Apple","Banana","Banana","Lime", "Lime", "Lime", "Lime","Melon", "Melon", "Melon", "Melon", "Melon"),3.05},
		};
	}
	
	@Test(dataProvider="basketDataProvider")
	public void testCalculateCost(List<String> shoppingCart,Double totalCost){
		Assert.assertEquals(basketPriceCalculator.calculateCost(shoppingCart),totalCost);		
	}
}
