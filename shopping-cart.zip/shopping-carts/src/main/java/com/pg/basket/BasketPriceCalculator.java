package com.pg.basket;

import java.util.List;

public interface BasketPriceCalculator {
	Double calculateCost(List<String> cart);
}
