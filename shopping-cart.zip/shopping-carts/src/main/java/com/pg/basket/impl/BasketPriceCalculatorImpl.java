package com.pg.basket.impl;


import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

import com.pg.basket.BasketPriceCalculator;
import com.pg.offers.DiscountService;
import com.pg.offers.impl.DiscountServiceImpl;
import com.pg.price.ItemPriceProvider;
import com.pg.price.ProductType;
/**
 * 
 * @author Prakash
 *
 */
public class BasketPriceCalculatorImpl implements BasketPriceCalculator{
	
	DiscountService discountService = new DiscountServiceImpl();
	public Double calculateCost(List<String> cart){	
		Map<String, Integer> countMap = cart.stream().collect(Collectors.groupingBy(Function.identity(), Collectors.summingInt(e -> 1))); 		
		Iterator<String> keySetItr = countMap.keySet().iterator();
		Double totalCost = 0.0;
		while(keySetItr.hasNext()){	
			String key = keySetItr.next();		
			int count = discountService.applyDiscount(ProductType.fromString(key), countMap.get(key));
			totalCost += count*ItemPriceProvider.getPrice(key);
		}
		return totalCost/100;
	}
}
