package com.pg.offers.impl;

import com.pg.offers.DiscountService;

import com.pg.price.ProductType;
/**
 * This can be service which fetches all discount details from other sources
 * @author Prakash
 *
 */
public class DiscountServiceImpl implements DiscountService{
	public int applyDiscount(ProductType productType, int count){
		if(ProductType.LIME == productType){
			return (count%3+(count/3)*2);
		} 
		if(ProductType.MELON == productType){
			return (count%2+count/2);
		}	
		return count;		
	}
}
