package com.pg.offers;

import com.pg.price.ProductType;

public interface DiscountService {
	int applyDiscount(ProductType productType, int count);
}
